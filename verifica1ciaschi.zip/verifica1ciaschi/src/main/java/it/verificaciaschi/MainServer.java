package it.verificaciaschi;

public class MainServer {
    public static void main(String[] args) {
        Server s = new Server();

        s.attenti();
        s.comunica();
    }
}