package it.verificaciaschi;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    String nomeServer = "localHost";
    int portaServer = 6789;
    Socket socket;
    BufferedReader tastiera;
    String stringaUtente;
    String strServer;
    DataOutputStream out;
    BufferedReader in;
    int esegui = 1;

    public Socket connetti(){

        System.out.println("CLIENT in esecuzione...");

        try {
            tastiera = new BufferedReader(new InputStreamReader(System.in));

            socket = new Socket(nomeServer, portaServer);

            out = new DataOutputStream(socket.getOutputStream());
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (UnknownHostException e) {
            System.out.println("Host sconosciuto! \n");
        } catch(Exception e){
                System.out.println(e.getMessage());
                System.out.println("Errore durante la connessione! \n");
                System.exit(1);
            }
            return socket;
    }

    public void comunica(){

        try {
            System.out.println("Digita un numero:  ");
            stringaUtente = tastiera.readLine();
            System.out.println("\nInvio al server e attendo... \n");
            out.writeBytes(stringaUtente + '\n');

            while(esegui == 1){

                System.out.println("\nScegli l'operatore (+, -, * , /):  ");
                stringaUtente = tastiera.readLine();
                System.out.println("\nInvio al server e attendo... \n");
                out.writeBytes(stringaUtente + '\n');

                System.out.println("\nDigita un'altro numero:  ");
                stringaUtente = tastiera.readLine();
                System.out.println("\nInvio al server e attendo... \n");
                out.writeBytes(stringaUtente + '\n');


                strServer = in.readLine();
                System.out.println("\n\nRisposta dal server: " + '\n' + strServer + '\n');
            
                System.out.println("\nEseguire un altra operazione? digita 1, altrimenti 0");
                stringaUtente = tastiera.readLine();
                System.out.println("\nInvio al server e attendo... \n");
                out.writeBytes(stringaUtente + '\n');
                esegui = Integer.parseInt(stringaUtente);
            }
            

            System.out.println("CLIENT: termina elaborazione e chiude connessione");
            socket.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("Errore durante la comunicazione col server!");
            System.exit(1);
        }

    }
}
