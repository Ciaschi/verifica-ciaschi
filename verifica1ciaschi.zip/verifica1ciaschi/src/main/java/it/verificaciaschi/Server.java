package it.verificaciaschi;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
//import integer.parseInt;

public class Server {
    ServerSocket server = null;
    Socket client = null;
    String strRicevuta = null;
    String operatore = null;
    int nr1 = 0;
    int nr2 = 0;
    BufferedReader in;
    DataOutputStream out;
    int esegui;

    public Socket attenti(){
        
        try{
            System.out.println("SERVER in attesa...");

            server = new ServerSocket(6789);

            client = server.accept();

            server.close();

            in = new BufferedReader(new InputStreamReader(client.getInputStream()));

            esegui = 1;

            out= new DataOutputStream(client.getOutputStream());
        }catch(Exception e){
            System.out.println(e.getMessage());
            System.out.println("Errore durante l'istanza del server!");
            System.exit(1);
        }

        return client;
    }
    
    public void comunica(){

        try{
            System.out.println("nr1: " + in.readLine());
            strRicevuta = in.readLine();
            nr1 = Integer.parseInt(strRicevuta);

            while(esegui == 1){

                System.out.println("operatore: " + in.readLine());
                operatore = in.readLine();

                System.out.println("\nnr2: " + in.readLine());
                strRicevuta = in.readLine();
                nr2 = Integer.parseInt(strRicevuta);

                if(operatore == "+"){
                    nr1 = nr1 + nr2;
                }else if(operatore == "-"){
                    nr1 = nr1 - nr2;
                }else if(operatore == "*"){
                    nr1 = nr1 * nr2;
                }else if(operatore == "/"){
                    nr1 = nr1 / nr2;
                }else{
                    System.out.println("ERRORE: operatore non valido. Passaggio annullato");
                    continue;
                }

                
                System.out.println("Risultato inviato al CLIENT  ");
                out.write(nr1 + '\n');

                System.out.println("Attendo risposta...");
                strRicevuta = in.readLine();
                esegui = Integer.parseInt(strRicevuta);

            }
            

            System.out.println("SERVER: fine elaborazione!");
            client.close();
        }catch(Exception e){

        }

    }
}
