package it.verificaciaschi;

public class MainClient {
    public static void main(String[] args) {
        Client c = new Client();

        c.connetti();
        c.comunica();
    }
}
